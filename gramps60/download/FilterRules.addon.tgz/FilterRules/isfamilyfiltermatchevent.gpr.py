#
# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2020  Matthias Kemmer
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
#
"""Filter rule that matches events of families matching a <family filter>."""

register(
    RULE,
    id="isfamilyfiltermatchevent",
    name=_("Events of families matching a <family filter>"),
    description=_("Events of families matching a <family filter>"),
    version = '1.0.22',
    authors=["Matthias Kemmer"],
    authors_email=["matt.familienforschung@gmail.com"],
    gramps_target_version="6.0",
    status=STABLE,
    fname="isfamilyfiltermatchevent.py",
    ruleclass="IsFamilyFilterMatchEvent",  # must be rule class name
    namespace="Event",  # one of the primary object classes
    help_url="Addon:Rule_expansions#Events_of_families_matching_a_.3Cfamily_filter.3E",
)
