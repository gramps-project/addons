#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# TMG Importer addon for Gramps genealogy program
#
# Copyright (C) 2017-2018 Sam Manzi
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
#

'''
Import from an Whollygenes - The Master Genealogist (TMG) Project backup file
(*.SQZ)
'''

#-------------------------------------------------------------------------
#
# Standard Python modules
#
#-------------------------------------------------------------------------
import logging
LOG = logging.getLogger(".TMGImport")

#-------------------------------------------------------------------------
#
# Gramps modules
#
#-------------------------------------------------------------------------
from gramps.gen.const import GRAMPS_LOCALE as glocale
_ = glocale.translation.gettext
from gramps.gen.const import URL_WIKISTRING

#-------------------------------------------------------------------------
#
# TMG library
#
#-------------------------------------------------------------------------

import libtmg

#-------------------------------------------------------------------------
#
# importData (based on importgpkg.py)
#
#-------------------------------------------------------------------------
def importSqzData(database, filename, user):
    """
    Function called by Gramps to import TMG project dataset(s).
    Uses TMG library to process .SQZ Backup file
    """
    LOG.info("TMG Importer: started processing %s", filename)
    #tmgabortimport = False   # Import Status
    importer = libtmg.importData
    info = importer(database, filename, user)
    LOG.info("TMG Importer: finished processing %s", filename)
    return info

#-------------------------------------------------------------------------
#
# Unsupported TMG formats. Imported data must be in a TMG *.SQZ backup file
#
#-------------------------------------------------------------------------
def importpjc(database, filename, user):
    '''
    *.PJC - Project Configuration File for TMG 5.0 to TMG 9.05
    '''
    import_dict = { 'gramps_wiki_import_pjc_direct_url' :
                         URL_WIKISTRING +
                             "Addon:TMGimporter#"
                             "Unsupported_formats" }
    user.notify_error(_("%s could not be opened") % filename,
                      _("Directly importing from TMG files is not supported\n"
                        "by the TMG Importer Addon.\n\n"
                        "You need to use an backup copy of the TMG project(*.sqz)\n\n"
                        "Ensure that your TMG project was created by:\n"
                        "TMG version 5.x or greater.\n\n"
                        "Your file:\n"
                        "*.PJC - Project Configuration File for TMG 5.0 to TMG 9.05\n\n"
                        "Please refer to:\n"
                        "%(gramps_wiki_import_pjc_direct_url)s" ) %
                                import_dict )
    return

def importtmg(database, filename, user):
    '''
    *.TMG - Version Control File for TMG 2.0 to TMG 4.0d
    '''
    import_dict = { 'gramps_wiki_import_pjc_direct_url' :
                         URL_WIKISTRING +
                             "Addon:TMGimporter#"
                             "Unsupported_formats" }
    user.notify_error(_("%s could not be opened") % filename,
                      _("Directly importing from TMG files is not supported\n"
                        "by the TMG Importer Addon.\n\n"
                        "You need to use an backup copy of TMG project(*.sqz)\n\n"
                        "Ensure that your TMG project was created by:\n"
                        "TMG version 5.x or greater.\n\n"
                        "Your file:\n"
                        "*.TMG - Version Control File for TMG 2.0 to TMG 4.0d\n\n"
                        "Please refer to:\n"
                        "%(gramps_wiki_import_pjc_direct_url)s" ) %
                                import_dict )
    return

def importver(database, filename, user):
    '''
    *.VER - Version Control File for TMG 1.2 and earlier
    '''
    import_dict = { 'gramps_wiki_import_pjc_direct_url' :
                         URL_WIKISTRING +
                             "Addon:TMGimporter#"
                             "Unsupported_formats" }
    user.notify_error(_("%s could not be opened") % filename,
                      _("Directly importing from TMG files is not supported\n"
                        "by the TMG Importer Addon.\n\n"
                        "You need to use an backup copy of TMG project(*.sqz)\n\n"
                        "Ensure that your TMG project was created by:\n"
                        "TMG version 5.x or greater.\n\n"
                        "Your file:\n"
                        "*.VER - Version Control File for TMG 1.2 and earlier\n\n"
                        "Please refer to:\n"
                        "%(gramps_wiki_import_pjc_direct_url)s" ) %
                                import_dict )
    return
