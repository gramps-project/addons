#
# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2018 Nick Hall
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
#
register(
    DATABASE,
    id="mongodb",
    name=_("MongoDB"),
    name_accell=_("_MongoDB Database"),
    description=_("MongoDB Database"),
    version = '1.0.16',
    gramps_target_version="6.1",
    status=UNSTABLE,
    audience=DEVELOPER,
    fname="mongodb.py",
    databaseclass="MongoDB",
    authors=["Nick Hall"],
    authors_email=["nick-h@gramps-project.org"],
    include_in_listing=False,
    requires_mod=["pymongo"],
)
